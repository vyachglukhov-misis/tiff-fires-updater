import { parentPort, workerData } from "worker_threads";
import fs from "fs";
import path from "path";
import { writeToTileFeature } from "./index_copy";

(async () => {
  try {
    const { feature, tileName } = workerData;

    const resultPath = await writeToTileFeature(feature, tileName);

    parentPort?.postMessage({ status: "done", tileName, path: resultPath });
  } catch (err: any) {
    parentPort?.postMessage({ status: "error", error: err.message });
  }
})();
